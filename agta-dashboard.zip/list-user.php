<?php
include 'function/connection.php';

session_start();

if($_SESSION['status']!="login"){
    header("location:index.php?pesan=belum_login");
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
		<meta name="description" content="Spruha -  Admin Panel HTML Dashboard Template">
		<meta name="author" content="Spruko Technologies Private Limited">
		<meta name="keywords" content="admin,dashboard,panel,bootstrap admin template,bootstrap dashboard,dashboard,themeforest admin dashboard,themeforest admin,themeforest dashboard,themeforest admin panel,themeforest admin template,themeforest admin dashboard,cool admin,it dashboard,admin design,dash templates,saas dashboard,dmin ui design">

		<!-- Favicon -->
		<link rel="icon" href="assets/img/brand/favicon.ico" type="image/x-icon"/>

		<!-- Title -->
		<title>AGTA | Dashboard</title>

		<!-- Bootstrap css-->
		<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>

		<!-- Icons css-->
		<link href="assets/plugins/web-fonts/icons.css" rel="stylesheet"/>
		<link href="assets/plugins/web-fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
		<link href="assets/plugins/web-fonts/plugin.css" rel="stylesheet"/>

		<!-- Internal DataTables css-->
		<link href="assets/plugins/datatable/dataTables.bootstrap4.min.css" rel="stylesheet" />
		<link href="assets/plugins/datatable/responsivebootstrap4.min.css" rel="stylesheet" />
		<link href="assets/plugins/datatable/fileexport/buttons.bootstrap4.min.css" rel="stylesheet" />

		<!-- Style css-->
		<link href="assets/css/style.css" rel="stylesheet">
		<link href="assets/css/skins.css" rel="stylesheet">
		<link href="assets/css/dark-style.css" rel="stylesheet">
		<link href="assets/css/colors/default.css" rel="stylesheet">

		<!-- Color css-->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="assets/css/colors/color.css">

		<!-- Select2 css -->
		<link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">

		<!-- Sidemenu css-->
		<link href="assets/css/sidemenu/sidemenu.css" rel="stylesheet">

		<!-- Internal Sweet-Alert css-->
		<link href="assets/plugins/sweet-alert/sweetalert.css" rel="stylesheet">

	</head>

	<body class="horizontalmenu dark-theme">

		<!-- Loader -->
		<div id="global-loader">
			<img src="assets/img/loader.svg" class="loader-img" alt="Loader">
		</div>
		<!-- End Loader -->

		<!-- Page -->
		<div class="page">
            <!-- Header -->
            <?php include 'layouts/header.php'; ?>
            <!-- End Header -->

            <!-- Navbar -->
            <?php include 'layouts/navbar.php'; ?>
            <!-- End Navbar -->

			<!-- Main Content-->
			<div class="main-content pt-2">
				<div class="container">
					<div class="inner-body">
                        <!-- Row -->
						<div class="row row-sm">
							<div class="col-lg-12">
								<div class="card custom-card overflow-hidden">
									<div class="card-body">
										<div>
											<h6 class="main-content-label mb-1">List Administrator</h6>
										</div>
										<div class="table-responsive pt-2">
											<table class="table" id="example1">
												<thead class="thead">
													<tr>
														<th class="wd-20p">User ID</th>
														<th class="wd-20p">Name</th>
														<th class="wd-20p">Email</th>
														<th class="wd-25p">Province</th>
														<th class="wd-15p">City</th>
														<th class="wd-20p">Sub District</th>
														<th class="wd-20p">Phone</th>
														<th class="wd-20p">Address</th>
													</tr>
												</thead>
												<tbody>
													<!--  -->
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- End Row -->
						<!-- Modal -->
						<div class="modal fade" id="myModal" role="dialog">
							<div class="modal-dialog">
								<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<h4 class="modal-title">Edit Administrator</h4>
									</div>
									<div class="modal-body">
										<form  method="POST" class="formproduk">
												<div class="form-group">
													<label for="judul">Name</label>
													<input type="hidden" name="iduser" id="iduser">
                                                    <input type="hidden" name="idprovince" id="idprovince">
													<input type="hidden" name="idcity" id="idcity">
													<input type="hidden" name="idsubdistrict" id="idsubdistrict">

													<input type="text" name="judul" class="form-control" id="name">
												</div>
												<div class="form-group">
													<label for="isi">Email</label>
                                                    <input type="email" name="judul" class="form-control" id="email">
												</div>
												<div class="form-group">
                                                    <label for="status">Province</label>
													<select name="status" class="form-control" id="province">
                                                        <option></option>
													</select>
												</div>
                                                <div class="form-group">
                                                    <label for="status">City</label>
													<select name="status" class="form-control" id="city">
                                                        <option></option>
													</select>
												</div>
                                                <div class="form-group">
                                                    <label for="status">Sub District</label>
													<select name="status" class="form-control" id="subdistrict">
                                                        <option></option>
													</select>
												</div>
												<div class="form-group">
													<label for="isi">Phone</label>
                                                    <input type="text" name="judul" class="form-control" id="phone">
												</div>
                                                <div class="form-group">
                                                    <label for="author">Address</label>
                                                    <textarea name="isi" class="form-control" cols="10" rows="2" id="address"></textarea>
                                                </div>
											<div class="modal-footer">
												<button type="button" class="btn btn-danger" id="delete">Delete</button>
												<button type="button" class="btn btn-info" id="edit">Edit</button>
											</div>
										</form>
									</div>
								</div>
							
							</div>
						</div>
						<!-- End Modal -->
					</div>
				</div>
			</div>
			<!-- End Main Content-->

			<!-- Main Footer-->
			<?php include 'layouts/footer.php'; ?>
			<!--End Footer-->
			
		</div>
		<!-- End Page -->

		<!-- Back-to-top -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- Jquery js-->
		<script src="assets/plugins/jquery/jquery.min.js"></script>

		<!-- Bootstrap js-->
		<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!-- Select2 js-->
		<script src="assets/plugins/select2/js/select2.min.js"></script>

		<!-- Internal Data Table js -->
		<script src="assets/plugins/datatable/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatable/dataTables.responsive.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/jszip.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/pdfmake.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/vfs_fonts.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.html5.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.print.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.colVis.min.js"></script>
		<script src="assets/js/table-data.js"></script>


		<!-- Perfect-scrollbar js -->
		<script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

		<!-- Sidebar js -->
		<script src="assets/plugins/sidebar/sidebar.js"></script>

		<!-- Sticky js -->
		<script src="assets/js/sticky.js"></script>

		<!-- Sweet Alert Js -->
		<script src="assets/plugins/sweet-alert/sweetalert.min.js"></script>
		<script src="assets/plugins/sweet-alert/jquery.sweet-alert.js"></script>

		<!-- Custom js -->
		<script src="assets/js/custom.js"></script>
		<script>
			$(document).ready(function(){
                var iduser;
				var idprovince, idcity;

				$('#example1').dataTable({
					"processing": true,
					// "stateSave": true,
					"ajax": "function/view-user.php",
					"order": [[0, "asc"]],
					"columns": [
						{data: 'id_user'},
						{data: 'name'},
						{data: 'email'},
						{data: 'province'},
						{data: 'city'},
                        {data: 'subdistrict'},
						{data: 'phone'},
                        {data: 'address'},
					],
					"bDestroy": true
				});

				$('#example1 tbody').on('click', 'tr', function () {
					var id = this.cells[0].innerHTML;
					// alert(id);
					
					$("#iduser").val(id).trigger("change");
					$("#myModal").modal("show");
				}); 

				$('#province').bind('change', function(e){
                    e.preventDefault();
                    idprovince = $(this).val();

                    $.ajax({
						url: 'function/ajaxrespon-city.php',
						type: 'POST',
						dataType: 'html',
						data: {
						    'idprovince' : idprovince
						},
						success: function (data) {
							$('#city').html(data);
						}
					});
                });

                $('#city').bind('change', function(e){
                    e.preventDefault();
                    idcity = $(this).val();

                    $.ajax({
						url: 'function/ajaxrespon-subdistrict.php',
						type: 'POST',
						dataType: 'html',
						data: {
						    'idcity' : idcity,
                            'idprovince' : idprovince
						},
						success: function (data) {
							$('#subdistrict').html(data);
						}
					});
                });

                $('#iduser').bind('change', function(e){
                    e.preventDefault();
                    iduser = $(this).val();

                    $.ajax({
                        url: 'function/ajaxrespon-user.php',
                        type: 'GET',
                        dataType: 'JSON',
                        data:{
                            'id_user': iduser
                        },
                        success:function(data){
                            $('#name').val(data['name']);
                            $('#email').val(data['email']);
                            $('#idprovince').val(data['id_province']).trigger('change');
							$('#idcity').val(data['id_city']).trigger('change');
							$('#idsubdistrict').val(data['id_subdistrict']).trigger('change');
                            $('#address').val(data['address']);
							$('#phone').val(data['phone']);
                        }
                    });
                });

                $('#idprovince').change(function(e){
                    e.preventDefault();
                    var idprovince = $(this).val();
                    // alert(idprovince);

                    $.ajax({
                        url : 'function/ajaxrespon-userprovince.php',
                        type: 'POST',
                        dataType: 'html',
                        data: {
                            'idprovince': idprovince
                        },
                        success: function(data){
                            $('#province').html(data);
                        }
                    });
                });

				$('#idcity').change( function(e){
					e.preventDefault();
					var idcity = $(this).val();
					var idprovince = $('#idprovince').val();

					$.ajax({
						url: 'function/ajaxrespon-usercity.php',
						type: 'POST',
						dataType: 'html',
						data: {
						    'idcity' : idcity,
							'idprovince' : idprovince
						},
						success: function (data) {
							$('#city').html(data);
						}
					});
				});

				$('#idsubdistrict').change(function(e){
					e.preventDefault();
                    var idcity = $('#idcity').val();
					var idprovince = $('#idprovince').val();
					var idsubdistrict = $(this).val();

                    $.ajax({
						url: 'function/ajaxrespon-usersubdistrict.php',
						type: 'POST',
						dataType: 'html',
						data: {
						    'idcity' : idcity,
                            'idprovince' : idprovince,
							'idsubdistrict' : idsubdistrict
						},
						success: function (data) {
							$('#subdistrict').html(data);
						}
					});
				});

				$('#edit').off().on("click", function(e){
                    e.preventDefault();
					$.ajax({
						url: 'function/update-user.php',
						type: 'POST',
						cache: false,
						data:{
							id: iduser,
							name: $('#name').val(),
							email: $('#email').val(),
							province: $('#province').val(),
							city: $('#city').val(),
							subdistrict: $('#subdistrict').val(),
							address : $('#address').val(),
							phone : $('#phone').val()
						},
						success: function(dataResult){
							var dataResult = JSON.parse(dataResult);
							if(dataResult.statusCode==200){
								swal(
									"Well Done!",
									"You've been updated this user",
									"success"
								);
								$('#myModal').modal('hide');
								$('#example1').dataTable().ajax.reload(null, false);
							}
						}
					});
				});

				$('#delete').off().on('click', function(e){
					e.preventDefault();
					$.ajax({
						url: "function/delete-user.php",
						method: "POST",
						data: {
							ids: iduser,
						},
						success: function(data){
							swal(
								"Well Done!",
								"You've been deleted this user",
								"success"
							);
							$('#myModal').modal('hide');
							$('#example1').DataTable().ajax.reload(null, false);
						}
					});
				});
			});
		</script>
	</body>
</html>