<?php
include 'function/connection.php';

session_start();

if($_SESSION['status']!="login"){
    header("location:index.php?pesan=belum_login");
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
		<meta name="description" content="Spruha -  Admin Panel HTML Dashboard Template">
		<meta name="author" content="Spruko Technologies Private Limited">
		<meta name="keywords" content="admin,dashboard,panel,bootstrap admin template,bootstrap dashboard,dashboard,themeforest admin dashboard,themeforest admin,themeforest dashboard,themeforest admin panel,themeforest admin template,themeforest admin dashboard,cool admin,it dashboard,admin design,dash templates,saas dashboard,dmin ui design">

		<!-- Favicon -->
		<link rel="icon" href="assets/img/brand/favicon.ico" type="image/x-icon"/>

		<!-- Title -->
		<title>AGTA | Dashboard</title>

		<!-- Bootstrap css-->
		<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>

		<!-- Icons css-->
		<link href="assets/plugins/web-fonts/icons.css" rel="stylesheet"/>
		<link href="assets/plugins/web-fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
		<link href="assets/plugins/web-fonts/plugin.css" rel="stylesheet"/>

		<!-- Internal DataTables css-->
		<link href="assets/plugins/datatable/dataTables.bootstrap4.min.css" rel="stylesheet" />
		<link href="assets/plugins/datatable/responsivebootstrap4.min.css" rel="stylesheet" />
		<link href="assets/plugins/datatable/fileexport/buttons.bootstrap4.min.css" rel="stylesheet" />

		<!-- Style css-->
		<link href="assets/css/style.css" rel="stylesheet">
		<link href="assets/css/skins.css" rel="stylesheet">
		<link href="assets/css/dark-style.css" rel="stylesheet">
		<link href="assets/css/colors/default.css" rel="stylesheet">

		<!-- Color css-->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="assets/css/colors/color.css">

		<!-- Select2 css -->
		<link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">

		<!-- Sidemenu css-->
		<link href="assets/css/sidemenu/sidemenu.css" rel="stylesheet">

		<!-- Internal Sweet-Alert css-->
		<link href="assets/plugins/sweet-alert/sweetalert.css" rel="stylesheet">

	</head>

	<body class="horizontalmenu dark-theme">

		<!-- Loader -->
		<div id="global-loader">
			<img src="assets/img/loader.svg" class="loader-img" alt="Loader">
		</div>
		<!-- End Loader -->

		<!-- Page -->
		<div class="page">
            <!-- Header -->
            <?php include 'layouts/header.php'; ?>
            <!-- End Header -->

            <!-- Navbar -->
            <?php include 'layouts/navbar.php'; ?>
            <!-- End Navbar -->

			<!-- Main Content-->
			<div class="main-content pt-2">
				<div class="container">
					<div class="inner-body">
                        <!-- Row -->
						<div class="row row-sm">
							<div class="col-lg-12">
								<div class="card custom-card overflow-hidden">
									<div class="card-body">
										<div>
											<h6 class="main-content-label mb-1">List Banner</h6>
										</div>
										<div class="table-responsive pt-2">
											<table class="table" id="example1">
												<thead class="thead">
													<tr>
														<th class="wd-20p">Banner ID</th>
														<th class="wd-20p">Title</th>
														<th class="wd-20p">Description</th>
														<th class="wd-20p">Images</th>
													</tr>
												</thead>
												<tbody>
													<!--  -->
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- End Row -->

						<!-- Modal -->
						<div class="modal fade" id="myModal" role="dialog">
							<div class="modal-dialog">
								<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<h4 class="modal-title">Edit Banner</h4>
									</div>
									<div class="modal-body">
										<form  method="POST" class="formproduk">
                                                <div class="form-group">
													<label for="nama">Title</label>
													<input type="hidden" name="idproduk" id="idbanner">
													<input type="hidden" name="idfoto" id="oldfoto">
													<input type="text" name="nama" class="form-control" id="judul" readonly>
												</div>
												<div class="form-group">
													<label for="harga">Description</label>
													<textarea name="isi" class="form-control" cols="10" rows="2" id="isi" readonly='readonly'></textarea>
												</div>
												<div class="form-group">
													<label for="warna">Images</label><br>
													<img src="#" alt="Foto tidak tersedia." id="foto" class="img-fluid mb-3" width="50%">
												</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-danger" id="delete">Delete</button><br>
											</div>
										</form>
									</div>
								</div>
							
							</div>
						</div>
						<!-- End Modal -->
					</div>
				</div>
			</div>
			<!-- End Main Content-->

			<!-- Main Footer-->
			<?php include 'layouts/footer.php'; ?>
			<!--End Footer-->
			
		</div>
		<!-- End Page -->

		<!-- Back-to-top -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- Jquery js-->
		<script src="assets/plugins/jquery/jquery.min.js"></script>

		<!-- Bootstrap js-->
		<!-- <script src="assets/plugins/bootstrap/js/popper.min.js"></script> -->
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!-- Select2 js-->
		<script src="assets/plugins/select2/js/select2.min.js"></script>

		<!-- Internal Data Table js -->
		<script src="assets/plugins/datatable/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatable/dataTables.responsive.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/jszip.min.js"></script>
		<!-- <script src="assets/plugins/datatable/fileexport/pdfmake.min.js"></script> -->
		<script src="assets/plugins/datatable/fileexport/vfs_fonts.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.html5.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.print.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.colVis.min.js"></script>
		<script src="assets/js/table-data.js"></script>


		<!-- Perfect-scrollbar js -->
		<script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

		<!-- Sidebar js -->
		<script src="assets/plugins/sidebar/sidebar.js"></script>

		<!-- Sticky js -->
		<script src="assets/js/sticky.js"></script>

		<!-- Sweet Alert Js -->
		<script src="assets/plugins/sweet-alert/sweetalert.min.js"></script>
		<script src="assets/plugins/sweet-alert/jquery.sweet-alert.js"></script>

		<!-- Custom js -->
		<script src="assets/js/custom.js"></script>
		<script>
			$(document).ready(function(){
				var fileName;

				$('#example1').dataTable({
					"processing": true,
					// "stateSave": true,
					"ajax": "function/view-banner.php",
					"order": [[0, "desc"]],
					"columns": [
						{data: 'id_banner'},
						{data: 'judul'},
						{data: 'deskripsi'},
						{
							"render": function (data, type, JsonResultRow, meta) {
								return '<img src="banners/'+JsonResultRow.gambar+'" class="img-fluid">';
							}
                    	}
					],
					"bDestroy": true
				});

				$('#example1 tbody').on('click', 'tr', function () {
					var id = this.cells[0].innerHTML;
					var idmodel = this.cells[1].innerHTML;
					// alert(id);
					
					$("#idbanner").val(id).trigger("change");
					$("#myModal").modal("show");
				}); 
				
				$('#idbanner').bind('change', function(e){
					e.preventDefault();
					var idbanner = $(this).val();

					$.ajax({
						url: 'function/ajaxrespon-banner.php',
						type: 'GET',
						dataType: 'json',
						data: {
						'id_blog' : idbanner
						},
						success: function (data) {
							$("#oldfoto").val(data['gambar']);
							$("#judul").val(data['judul']);
							$("#isi").val(data['isi']);
							$("#foto").attr("src","banners/" + data['gambar']);
						}
					});

					$('#delete').off().on('click', function(e){
						$.ajax({
							url: 'function/delete-banner.php',
							method: "POST",
							data: {
								ids: idbanner,
							},
							success:function(data){
								swal(
									"Well Done!",
									"You've been deleted this banner",
									"success"
								);
								$('#myModal').modal('hide');
								$('#example1').DataTable().ajax.reload(null, false);
							}
						})
					});
				});
			});
		</script>
	</body>
</html>