<?php
    include 'function/connection.php';

    session_start();

    if($_SESSION['status']!="login"){
        header("location:index.php?pesan=belum_login");
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
		<meta name="description" content="Dashlead -  Admin Panel HTML Dashboard Template">
		<meta name="author" content="Spruko Technologies Private Limited">
		<meta name="keywords" content="admin,dashboard,panel,bootstrap admin template,bootstrap dashboard,dashboard,themeforest admin dashboard,themeforest admin,themeforest dashboard,themeforest admin panel,themeforest admin template,themeforest admin dashboard,cool admin,it dashboard,admin design,dash templates,saas dashboard,dmin ui design">

		<!-- Favicon -->
		<link rel="icon" href="assets/img/brand/favicon.ico" type="image/x-icon"/>

		<!-- Title -->
		<title>AGTA | Dashboard</title>

		<!-- Bootstrap css-->
		<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>

		<!-- Icons css-->
		<link href="assets/plugins/web-fonts/icons.css" rel="stylesheet"/>
		<link href="assets/plugins/web-fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
		<link href="assets/plugins/web-fonts/plugin.css" rel="stylesheet"/>

		<!-- Style css-->
		<link href="assets/css/style.css" rel="stylesheet">
		<link href="assets/css/skins.css" rel="stylesheet">
		<link href="assets/css/dark-style.css" rel="stylesheet">
		<link href="assets/css/colors/default.css" rel="stylesheet">

		<!-- Color css-->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="assets/css/colors/color.css">

		<!-- Select2 css -->
		<link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">

		<!-- Sidemenu css-->
		<link href="assets/css/sidemenu/sidemenu.css" rel="stylesheet">

		<!-- Internal Sweet-Alert css-->
		<link href="assets/plugins/sweet-alert/sweetalert.css" rel="stylesheet">

		<!-- InternalFileupload css-->
		<link href="assets/plugins/fileuploads/css/fileupload.css" rel="stylesheet" type="text/css"/>

	</head>

	<body class="horizontalmenu dark-theme">

		<!-- Loader -->
		<div id="global-loader">
			<img src="assets/img/loader.svg" class="loader-img" alt="Loader">
		</div>
		<!-- End Loader -->

		<!-- Page -->
		<div class="page">
            <!-- Header -->
            <?php include 'layouts/header.php'; ?>
            <!-- End Header -->

            <!-- Navbar -->
            <?php include 'layouts/navbar.php'; ?>
            <!-- End Navbar -->

			<!-- Main Content-->
			<div class="main-content pt-0">
				<div class="container">
					<!-- row -->
                    <div class="row row-sm pt-2">
						<div class="col-lg-12 col-md-12">
							<input type="hidden" name="" id="product_id" />
							<form id="formadd" method="post">
								<div class="card custom-card">
									<div class="card-body">
										<div>
											<h5 class="main-content-label mb-2">Add Administrator</h5>
										</div>
										<div class="">
											<div class="row row-xs align-items-center mg-b-20">
												<div class="col-md-4">
													<label class="mg-b-0">Name</label>
												</div>
												<div class="col-md-8 mg-t-5 mg-md-t-0">
													<input class="form-control" placeholder="Enter Name" type="text" id="name" required>
												</div>
											</div>
											<div class="row row-xs align-items-center mg-b-20">
												<div class="col-md-4">
													<label class="mg-b-0">Email</label>
												</div>
												<div class="col-md-8 mg-t-5 mg-md-t-0">
                                                    <input class="form-control" placeholder="Enter Email" type="email" id="email" required>
												</div>
											</div>
                                            <div class="row row-xs align-items-center mg-b-20">
												<div class="col-md-4">
													<label class="mg-b-0">Password</label>
												</div>
												<div class="col-md-8 mg-t-5 mg-md-t-0">
													<input class="form-control" type="password" id="password" placeholder="Enter Password"/>
												</div>
											</div>
                                            <div class="row row-xs align-items-center mg-b-20">
												<div class="col-md-4">
													<label class="mg-b-0">Province</label>
												</div>
												<div class="col-md-8 mg-t-5 mg-md-t-0">
                                                    <?php
                                                        $sql_provinsi = mysqli_query($koneksi,"SELECT * FROM province ORDER BY province ASC");
                                                    ?>
                                                    <select name="" id="province" class="form-control">
                                                        <option value="" selected>-- Select Province --</option>
                                                        <?php                       
                                                            while($rs_provinsi = mysqli_fetch_assoc($sql_provinsi)){ 
                                                                echo '<option value="'.$rs_provinsi['id'].'">'.$rs_provinsi['province'].'</option>';
                                                            }                        
                                                        ?>
                                                    </select>
												</div>
											</div>
                                            <div class="row row-xs align-items-center mg-b-20">
												<div class="col-md-4">
													<label class="mg-b-0">City</label>
												</div>
												<div class="col-md-8 mg-t-5 mg-md-t-0">
                                                    <select name="" id="city" class="form-control">
                                                        <option></option>
                                                    </select>
												</div>
											</div>
                                            <div class="row row-xs align-items-center mg-b-20">
												<div class="col-md-4">
													<label class="mg-b-0">Sub District</label>
												</div>
												<div class="col-md-8 mg-t-5 mg-md-t-0">
                                                    <select name="" id="subdistrict" class="form-control">
                                                        <option></option>
                                                    </select>
												</div>
											</div>
											<div class="row row-xs align-items-center mg-b-20">
												<div class="col-md-4">
													<label class="mg-b-0">Phone</label>
												</div>
												<div class="col-md-8 mg-t-5 mg-md-t-0">
													<input class="form-control" placeholder="Enter Phone Number" type="text" id="phone" required>
												</div>
											</div>
                                            <div class="row row-xs align-items-center mg-b-20">
												<div class="col-md-4">
													<label class="mg-b-0">Address</label>
												</div>
												<div class="col-md-8 mg-t-5 mg-md-t-0">
                                                    <textarea id="address" class="form-control" name="editordata" rows="5" cols="20" placeholder="Enter Address"></textarea>
												</div>
											</div>
											<div class="form-group row justify-content-end mb-0">
												<div class="col-md-8 pl-md-2">
													<input type="button" class="btn ripple btn-primary pd-x-30 mg-r-5" id="save" value="Save"/>
													<input type="button" class="btn ripple btn-secondary pd-x-30" id="cancel" value="Clear" />
												</div>
											</div>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
					<!-- END row -->
				</div>
			</div>
			<!-- End Main Content-->

			<!-- Main Footer-->
			<?php include 'layouts/footer.php'; ?>
			<!--End Footer-->

		</div>
		<!-- End Page -->

		<!-- Back-to-top -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- Jquery js-->
		<<script src="assets/plugins/jquery/jquery.min.js"></script>

        <!-- Bootstrap js-->
        <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

        <!-- Internal Jquery-steps js-->
        <script src="assets/plugins/jquery-steps/jquery.steps.min.js"></script>

        <!-- Internal Accordion-Wizard-Form js-->
        <script src="assets/plugins/accordion-Wizard-Form/jquery.accordion-wizard.min.js"></script>

        <!-- Internal Form-wizard js-->
        <script src="assets/js/form-wizard.js"></script>

        <!-- Perfect-scrollbar js -->
        <script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

        <!-- Sidebar js -->
        <script src="assets/plugins/sidebar/sidebar.js"></script>

        <!-- Select2 js-->
        <script src="assets/plugins/select2/js/select2.min.js"></script>

        <!-- Sticky js -->
        <script src="assets/js/sticky.js"></script>

		<!-- Sweet Alert Js -->
		<script src="assets/plugins/sweet-alert/sweetalert.min.js"></script>
		<script src="assets/plugins/sweet-alert/jquery.sweet-alert.js"></script>

		<!-- Internal Fileuploads js-->
		<script src="assets/plugins/fileuploads/js/fileupload.js"></script>
        <script src="assets/plugins/fileuploads/js/file-upload.js"></script>

        <!-- Custom js -->
        <script src="assets/js/custom.js"></script>

        <script>
            $(document).ready(function(){
                var idprovince, idcity;
                var name, email, password, province, city, subdistrict, address, phone;

                $('#province').bind('change', function(e){
                    e.preventDefault();
                    idprovince = $(this).val();

                    $.ajax({
						url: 'function/ajaxrespon-city.php',
						type: 'POST',
						dataType: 'html',
						data: {
						    'idprovince' : idprovince
						},
						success: function (data) {
							$('#city').html(data);
						}
					});
                });

                $('#city').bind('change', function(e){
                    e.preventDefault();
                    idcity = $(this).val();

                    $.ajax({
						url: 'function/ajaxrespon-subdistrict.php',
						type: 'POST',
						dataType: 'html',
						data: {
						    'idcity' : idcity,
                            'idprovince' : idprovince
						},
						success: function (data) {
							$('#subdistrict').html(data);
						}
					});
                });

                $('#save').off().on('click', function(e){
                    name = $('#name').val();
                    email = $('#email').val();
                    password = $('#password').val();
                    province = $('#province').val();
                    city = $('#city').val();
                    subdistrict = $('#subdistrict').val();
                    address = $('#address').val();
					phone = $('#phone').val();

                    if(name=="" || email=="" || password=="" || province=="" || city=="" || subdistrict=="" || address=="" || phone==""){
                        swal(
							"Oopss..",
							"Please fill in all data",
						    "error"
						);
                    }else{
                        $.ajax({
                            url: 'function/add-user.php',
                            type: 'POST',
                            cache: false,
                            data:{
                                name : name,
                                email : email,
                                password : password,
                                province : province,
                                city : city,
                                subdistrict : subdistrict,
                                address : address,
								phone : phone
                            },
                            success: function(dataResult){
                                var dataResult = JSON.parse(dataResult);
                                if(dataResult.statusCode==200){
                                    swal(
										"Success!",
										"You've been saved this user!",
										"success"
									);
									$('#formadd').trigger('reset');
                                }
                            }
                        });
                    }
                });
			});
        </script>
</body>
</html>