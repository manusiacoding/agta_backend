<?php
include 'function/connection.php';

session_start();

if($_SESSION['status']!="login"){
    header("location:index.php?pesan=belum_login");
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
		<meta name="description" content="Spruha -  Admin Panel HTML Dashboard Template">
		<meta name="author" content="Spruko Technologies Private Limited">
		<meta name="keywords" content="admin,dashboard,panel,bootstrap admin template,bootstrap dashboard,dashboard,themeforest admin dashboard,themeforest admin,themeforest dashboard,themeforest admin panel,themeforest admin template,themeforest admin dashboard,cool admin,it dashboard,admin design,dash templates,saas dashboard,dmin ui design">

		<!-- Favicon -->
		<link rel="icon" href="assets/img/brand/favicon.ico" type="image/x-icon"/>

		<!-- Title -->
		<title>AGTA | Dashboard</title>

		<!-- Bootstrap css-->
		<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>

		<!-- Icons css-->
		<link href="assets/plugins/web-fonts/icons.css" rel="stylesheet"/>
		<link href="assets/plugins/web-fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
		<link href="assets/plugins/web-fonts/plugin.css" rel="stylesheet"/>

		<!-- Internal DataTables css-->
		<link href="assets/plugins/datatable/dataTables.bootstrap4.min.css" rel="stylesheet" />
		<link href="assets/plugins/datatable/responsivebootstrap4.min.css" rel="stylesheet" />
		<link href="assets/plugins/datatable/fileexport/buttons.bootstrap4.min.css" rel="stylesheet" />

		<!-- Style css-->
		<link href="assets/css/style.css" rel="stylesheet">
		<link href="assets/css/skins.css" rel="stylesheet">
		<link href="assets/css/dark-style.css" rel="stylesheet">
		<link href="assets/css/colors/default.css" rel="stylesheet">

		<!-- Color css-->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="assets/css/colors/color.css">

		<!-- Select2 css -->
		<link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">

		<!-- Sidemenu css-->
		<link href="assets/css/sidemenu/sidemenu.css" rel="stylesheet">

		<!-- Internal Sweet-Alert css-->
		<link href="assets/plugins/sweet-alert/sweetalert.css" rel="stylesheet">

	</head>

	<body class="horizontalmenu dark-theme">

		<!-- Loader -->
		<div id="global-loader">
			<img src="assets/img/loader.svg" class="loader-img" alt="Loader">
		</div>
		<!-- End Loader -->

		<!-- Page -->
		<div class="page">
            <!-- Header -->
            <?php include 'layouts/header.php'; ?>
            <!-- End Header -->

            <!-- Navbar -->
            <?php include 'layouts/navbar.php'; ?>
            <!-- End Navbar -->

			<!-- Main Content-->
			<div class="main-content pt-2">
				<div class="container">
					<div class="inner-body">
                        <!-- Row -->
						<div class="row row-sm">
							<div class="col-lg-12">
								<div class="card custom-card overflow-hidden">
									<div class="card-body">
										<div>
											<h6 class="main-content-label mb-1">List Product</h6>
										</div>
										<div class="table-responsive pt-2">
											<table class="table" id="example1">
												<thead class="thead">
													<tr>
														<th class="wd-20p">Product ID</th>
														<th class="wd-20p">Model ID</th>
														<th class="wd-20p">Product Name</th>
														<th class="wd-25p">Price</th>
														<th class="wd-20p">Description</th>
														<th class="wd-15p">Product Type</th>
														<th class="wd-20p">Model Name / Color</th>
														<th class="wd-20p">Stock</th>
														<th class="wd-20p">Weight</th>
														<th class="wd-20p">Size</th>
														<th class="wd-20p">Images</th>
													</tr>
												</thead>
												<tbody>
													<!--  -->
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- End Row -->

						<!-- Modal -->
						<div class="modal fade" id="myModal" role="dialog">
							<div class="modal-dialog">
								<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<h4 class="modal-title">Edit Product</h4>
									</div>
									<div class="modal-body">
										<form  method="POST" class="formproduk">
												<div class="form-group">
													<label for="nama">Product Name</label>
													<input type="hidden" name="idproduk" id="idproduk">
													<input type="hidden" name="idmodelproduk" id="idmodelproduk">
													<input type="hidden" name="idfoto" id="oldfoto">
													<input type="text" name="nama" class="form-control" id="nama">
												</div>
												<div class="form-group">
													<label for="harga">Price</label>
													<input type="text" name="harga" class="form-control" id="harga" >
												</div>
												<div class="form-group">
													<label for="deskripsi">Description</label>
													<textarea name="deskripsi" class="form-control" cols="10" rows="2" id="deskripsi" ></textarea>
												</div>
												<div class="form-group">
													<label for="jenis">Product Type</label>
													<select class="form-control" id="jenis" name="jenis">
                                                        <option value="Rumah Tangga">Rumah Tangga</option>
                                                        <option value="Buku Anak">Buku Anak</option>
                                                        <option value="Pre Order">Pre Order</option>
                                                        <option value="Barang Rumah">Barang Rumah</option>
                                                        <option value="Mainan Anak">Mainan Anak</option>
                                                        <option value="Ready Supplier">Ready Supplier</option>
                                                        <option value="Kebutuhan Anak">Kebutuhan Anak</option>
                                                    </select>
												</div>
												<div class="form-group">
													<label for="kota">Model Name / Color</label>
													<input type="text" name="model" class="form-control" id="model" >
												</div>
												<div class="form-group">
													<label for="type">Stock</label>
													<input type="text" name="stock" class="form-control" id="stock">
												</div>
												<div class="form-group">
													<label for="type">Weight</label>
													<input type="text" name="berat" class="form-control" id="berat">
												</div>
												<div class="form-group">
													<label for="warna">Size</label>
													<input type="text" name="size" class="form-control" id="size">
												</div>
												<div class="form-group">
													<label for="warna">Images</label><br>
													<!-- <input type="text" name="warna" class="form-control" id="foto"> -->
													<img src="#" alt="Foto tidak tersedia." id="foto" class="img-fluid mb-3" width="50%">
  													<input class="form-control" accept="image/*" type="file" id="formFile" name='file' />
												</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-danger" id="delete">Delete Product</button><br>
												<button type="button" class="btn btn-danger" id="deletemodel">Delete Only This Model</button>
												<button type="button" class="btn btn-info" id="edit">Edit</button>
											</div>
										</form>
									</div>
								</div>
							
							</div>
						</div>
						<!-- End Modal -->
					</div>
				</div>
			</div>
			<!-- End Main Content-->

			<!-- Main Footer-->
			<?php include 'layouts/footer.php'; ?>
			<!--End Footer-->
			
		</div>
		<!-- End Page -->

		<!-- Back-to-top -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- Jquery js-->
		<script src="assets/plugins/jquery/jquery.min.js"></script>

		<!-- Bootstrap js-->
		<!-- <script src="assets/plugins/bootstrap/js/popper.min.js"></script> -->
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!-- Select2 js-->
		<script src="assets/plugins/select2/js/select2.min.js"></script>

		<!-- Internal Data Table js -->
		<script src="assets/plugins/datatable/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatable/dataTables.responsive.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/jszip.min.js"></script>
		<!-- <script src="assets/plugins/datatable/fileexport/pdfmake.min.js"></script> -->
		<script src="assets/plugins/datatable/fileexport/vfs_fonts.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.html5.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.print.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.colVis.min.js"></script>
		<script src="assets/js/table-data.js"></script>


		<!-- Perfect-scrollbar js -->
		<script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

		<!-- Sidebar js -->
		<script src="assets/plugins/sidebar/sidebar.js"></script>

		<!-- Sticky js -->
		<script src="assets/js/sticky.js"></script>

		<!-- Sweet Alert Js -->
		<script src="assets/plugins/sweet-alert/sweetalert.min.js"></script>
		<script src="assets/plugins/sweet-alert/jquery.sweet-alert.js"></script>

		<!-- Custom js -->
		<script src="assets/js/custom.js"></script>
		<script>
			$(document).ready(function(){
				// $('#jenis').select2();
				var fileName;
				const chooseFile = document.getElementById("formFile");
				const imgPreview = document.getElementById("foto");
				function getImgData() {
				const files = chooseFile.files[0];
					if (files) {
							const fileReader = new FileReader();
							fileReader.readAsDataURL(files);
							fileReader.addEventListener("load", function () {
							// imgPreview.style.display = "block";
							// imgPreview.innerHTML = '<img src="' + this.result + '" />';
							$("#foto").attr('src', this.result);
							// alert(files.name);
						});    
					}
				}
				chooseFile.addEventListener("change", function () {
					getImgData();
				});

				$('#example1').dataTable({
					"processing": true,
					// "stateSave": true,
					"ajax": "function/view.php",
					"order": [[0, "desc"]],
					"columns": [
						{data: 'id_produk'},
						{data: 'id_model'},
						{data: 'nama_produk'},
						{data: 'harga_produk'},
						{data: 'deskripsi_produk'},
						{data: 'jenis_produk'},
						{data: 'nama_model'},
						{data: 'stok_produk'},
						{data: 'berat_produk'},
						{data: 'ukuran_produk'},
						// {data: 'gambar_produk'},
						{
							"render": function (data, type, JsonResultRow, meta) {
								return '<img src="images/'+JsonResultRow.gambar_produk+'" class="img-fluid">';
							}
                    	}
					],
					"bDestroy": true
				});
				// $('#example1').DataTable();
				// var table = $('#example1').DataTable();
				// setInterval( function () {
				// 	table.ajax.reload( null, false ); // page not reload but data in datatable auto reload in 3 seconds
				// }, 3000 );
				$('#example1 tbody').on('click', 'tr', function () {
					var id = this.cells[0].innerHTML;
					var idmodel = this.cells[1].innerHTML;
					// alert(id);
					
					$("#idproduk").val(id).trigger("change");
					$("#idmodelproduk").val(idmodel).trigger("change");
					$("#myModal").modal("show");
				}); 
				//show modal data
				$("#idmodelproduk").bind("change", function(){
					// alert($(this).val()); 
					var idmodelproduk = $(this).val();
					$.ajax({
						url: 'function/ajaxrespon.php',
						type: 'GET',
						dataType: 'json',
						data: {
						'id_model' : idmodelproduk
						},
						success: function (data) {
							$("#nama").val(data['nama_produk']);
							$("#harga").val(data['harga_produk']);
							$("#deskripsi").val(data['deskripsi_produk']);
							$("#berat").val(data['berat_produk']);
							$('#jenis').val(data['jenis_produk']).attr('selected','selected');
							$("#model").val(data['nama_model']);
							$("#stock").val(data['stock_produk']);
							$("#size").val(data['ukuran_produk']);
							$("#oldfoto").val(data['gambar_produk']);
							$("#foto").attr("src","images/" + data['gambar_produk']);
						}
					});
				});
				
				$('#idproduk').bind('change', function(e){
						e.preventDefault();
						var idproduk = $(this).val();
						
						$('#delete').on('click', function(){
							// e.preventDefault();
							$.ajax({
								url: "function/delete-product.php",
								method: "POST",
								data: {
									ids: idproduk,
									// gambar: gambar
								},
								success: function(data){
									// $('#hapus_'+id).fadeOut('slow');
									swal(
										"Well Done!",
										"You've been deleted this product",
										"success"
									);
									$('#myModal').modal('hide');
									$('#example1').DataTable().ajax.reload(null, false);
								}
							});
						});
						$('#deletemodel').on('click', function(){
							// e.preventDefault();
							var idmodelproduk = $('#idmodelproduk').val();
							var gambar = $('#oldfoto').val();
							$.ajax({
								url: "function/delete-model-product.php",
								method: "POST",
								data: {
									id: idmodelproduk,
									gambar: gambar
								},
								success: function(data){
									// $('#hapus_'+id).fadeOut('slow');
									swal(
										"Well Done!",
										"You've been deleted this model product",
										"success"
									);
									$('#myModal').modal('hide');
									$('#example1').DataTable().ajax.reload(null, false);
								}
							});
						});
				});
				$('#formFile').change(function(e){
					e.preventDefault();
					fileName = e.target.files[0].name;
				});
				$('#edit').off().on("click", function(e){
						var file_data = $('#formFile').prop('files')[0];
								var form_data = new FormData();                  
								form_data.append('file', file_data);
								$.ajax({
									type: 'POST',
									url: 'function/upload-file.php',
									contentType: false,
									processData: false,
									data: form_data,
									success:function(response) {
										$.ajax({
											url: "function/update-product.php",
											type: "POST",
											cache: false,
											data:{
												id: $('#idproduk').val(),
												idmodel: $('#idmodelproduk').val(),
												oldfoto: $('#oldfoto').val(),
												nama: $('#nama').val(),
												harga: $('#harga').val(),
												deskripsi: $('#deskripsi').val(),
												jenis: $('#jenis').val(),
												model: $('#model').val(),
												stock: $('#stock').val(),
												berat: $('#berat').val(),
												size: $('#size').val(),
												gambar: fileName,
											},
											success: function(dataResult){
												var dataResult = JSON.parse(dataResult);
												if(dataResult.statusCode==200){
													swal(
														"Well Done!",
														"You've been updated this product",
														"success"
													);
													$('#myModal').modal('hide');
													$('#example1').DataTable().ajax.reload(null, false);
												}
											}
										});
										$('#formFile').val('');
									}
								});
							return false;
						
				});
			});
		</script>
	</body>
</html>