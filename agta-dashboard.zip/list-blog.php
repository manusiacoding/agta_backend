<?php
include 'function/connection.php';

session_start();

if($_SESSION['status']!="login"){
    header("location:index.php?pesan=belum_login");
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
		<meta name="description" content="Spruha -  Admin Panel HTML Dashboard Template">
		<meta name="author" content="Spruko Technologies Private Limited">
		<meta name="keywords" content="admin,dashboard,panel,bootstrap admin template,bootstrap dashboard,dashboard,themeforest admin dashboard,themeforest admin,themeforest dashboard,themeforest admin panel,themeforest admin template,themeforest admin dashboard,cool admin,it dashboard,admin design,dash templates,saas dashboard,dmin ui design">

		<!-- Favicon -->
		<link rel="icon" href="assets/img/brand/favicon.ico" type="image/x-icon"/>

		<!-- Title -->
		<title>AGTA | Dashboard</title>

		<!-- Bootstrap css-->
		<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>

		<!-- Icons css-->
		<link href="assets/plugins/web-fonts/icons.css" rel="stylesheet"/>
		<link href="assets/plugins/web-fonts/font-awesome/font-awesome.min.css" rel="stylesheet">
		<link href="assets/plugins/web-fonts/plugin.css" rel="stylesheet"/>

		<!-- Internal DataTables css-->
		<link href="assets/plugins/datatable/dataTables.bootstrap4.min.css" rel="stylesheet" />
		<link href="assets/plugins/datatable/responsivebootstrap4.min.css" rel="stylesheet" />
		<link href="assets/plugins/datatable/fileexport/buttons.bootstrap4.min.css" rel="stylesheet" />

		<!-- Style css-->
		<link href="assets/css/style.css" rel="stylesheet">
		<link href="assets/css/skins.css" rel="stylesheet">
		<link href="assets/css/dark-style.css" rel="stylesheet">
		<link href="assets/css/colors/default.css" rel="stylesheet">

		<!-- Color css-->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="assets/css/colors/color.css">

		<!-- Select2 css -->
		<link href="assets/plugins/select2/css/select2.min.css" rel="stylesheet">

		<!-- Sidemenu css-->
		<link href="assets/css/sidemenu/sidemenu.css" rel="stylesheet">

		<!-- Internal Sweet-Alert css-->
		<link href="assets/plugins/sweet-alert/sweetalert.css" rel="stylesheet">

	</head>

	<body class="horizontalmenu dark-theme">

		<!-- Loader -->
		<div id="global-loader">
			<img src="assets/img/loader.svg" class="loader-img" alt="Loader">
		</div>
		<!-- End Loader -->

		<!-- Page -->
		<div class="page">
            <!-- Header -->
            <?php include 'layouts/header.php'; ?>
            <!-- End Header -->

            <!-- Navbar -->
            <?php include 'layouts/navbar.php'; ?>
            <!-- End Navbar -->

			<!-- Main Content-->
			<div class="main-content pt-2">
				<div class="container">
					<div class="inner-body">
                        <!-- Row -->
						<div class="row row-sm">
							<div class="col-lg-12">
								<div class="card custom-card overflow-hidden">
									<div class="card-body">
										<div>
											<h6 class="main-content-label mb-1">List Blog</h6>
										</div>
										<div class="table-responsive pt-2">
											<table class="table" id="example1">
												<thead class="thead">
													<tr>
														<th class="wd-20p">Blog ID</th>
														<th class="wd-20p">Title</th>
														<th class="wd-20p">Content</th>
														<th class="wd-25p">Upload Date</th>
														<th class="wd-15p">Author</th>
														<th class="wd-20p">Images</th>
														<th class="wd-20p">Status</th>
													</tr>
												</thead>
												<tbody>
													<!--  -->
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- End Row -->
						<!-- Modal -->
						<div class="modal fade" id="myModal" role="dialog">
							<div class="modal-dialog">
								<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<h4 class="modal-title">Edit Blog</h4>
									</div>
									<div class="modal-body">
										<form  method="POST" class="formproduk">
												<div class="form-group">
													<label for="judul">Title</label>
													<input type="hidden" name="idblog" id="idblog">
													<input type="hidden" name="idfoto" id="oldfoto">
													<input type="text" name="judul" class="form-control" id="judul" required="">
												</div>
												<div class="form-group">
													<label for="isi">Content</label>
													<textarea name="isi" class="form-control" cols="10" rows="2" id="isi" required=""></textarea>
												</div>
												<div class="form-group">
													<label for="author">Author</label>
													<input type="text" name="author" class="form-control" id="author" required="">
												</div>
												<div class="form-group">
													<label for="status">Status</label>
													<select name="status" class="form-control" id="status" required="">
														<option value="Active">Active</option>
														<option value="Inactive">Inactive</option>
													</select>
												</div>
												<div class="form-group">
												<div class="form-group">
													<label for="warna">Images</label><br>
													<!-- <input type="text" name="warna" class="form-control" id="foto"> -->
													<img src="#" alt="Foto tidak tersedia." id="foto" class="img-fluid mb-3" width="50%">
  													<input class="form-control" accept="image/*" type="file" id="formFile" name='file' />
												</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-danger" id="delete">Delete</button>
												<button type="button" class="btn btn-info" id="edit">Edit</button>
											</div>
										</form>
									</div>
								</div>
							
							</div>
						</div>
						<!-- End Modal -->
					</div>
				</div>
			</div>
			<!-- End Main Content-->

			<!-- Main Footer-->
			<?php include 'layouts/footer.php'; ?>
			<!--End Footer-->
			
		</div>
		<!-- End Page -->

		<!-- Back-to-top -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- Jquery js-->
		<script src="assets/plugins/jquery/jquery.min.js"></script>

		<!-- Bootstrap js-->
		<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!-- Select2 js-->
		<script src="assets/plugins/select2/js/select2.min.js"></script>

		<!-- Internal Data Table js -->
		<script src="assets/plugins/datatable/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatable/dataTables.responsive.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/jszip.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/pdfmake.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/vfs_fonts.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.html5.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.print.min.js"></script>
		<script src="assets/plugins/datatable/fileexport/buttons.colVis.min.js"></script>
		<script src="assets/js/table-data.js"></script>


		<!-- Perfect-scrollbar js -->
		<script src="assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

		<!-- Sidebar js -->
		<script src="assets/plugins/sidebar/sidebar.js"></script>

		<!-- Sticky js -->
		<script src="assets/js/sticky.js"></script>

		<!-- Sweet Alert Js -->
		<script src="assets/plugins/sweet-alert/sweetalert.min.js"></script>
		<script src="assets/plugins/sweet-alert/jquery.sweet-alert.js"></script>

		<!-- Custom js -->
		<script src="assets/js/custom.js"></script>
		<script>
			$(document).ready(function(){
				var fileName;
				const chooseFile = document.getElementById("formFile");
				const imgPreview = document.getElementById("foto");
				function getImgData() {
				const files = chooseFile.files[0];
					if (files) {
							const fileReader = new FileReader();
							fileReader.readAsDataURL(files);
							fileReader.addEventListener("load", function () {
							// imgPreview.style.display = "block";
							// imgPreview.innerHTML = '<img src="' + this.result + '" />';
							$("#foto").attr('src', this.result);
							// alert(files.name);
						});    
					}
				}
				chooseFile.addEventListener("change", function () {
					getImgData();
				});
				
				$('#example1').dataTable({
					"processing": true,
					// "stateSave": true,
					"ajax": "function/view-blog.php",
					"order": [[0, "desc"]],
					"columns": [
						{data: 'id_blog'},
						{data: 'judul'},
						{data: 'isi'},
						{data: 'tanggal_upload'},
						{data: 'author'},
						{
                            "render": function (data, type, JsonResultRow, meta) {
                                return '<img src="blogs/'+JsonResultRow.gambar+'" class="img-fluid">';
                            }
                        },
						{ "render": function ( data, type, row ) {
                                var html = ""
                                if(row.status == 'Active'){
                                    html = '<span style="color:#2AFF00;">Active</span>'
                                }else{
                                    html = '<span style="color:red;">Inactive</span>'
                                }
                                return html;
                            }
                        },
					],
					"bDestroy": true
				});

				$('#example1 tbody').on('click', 'tr', function () {
					var id = this.cells[0].innerHTML;
					// alert(id);
					
					$("#idblog").val(id).trigger("change");
					$("#myModal").modal("show");
				});

				$('#formFile').change(function(e){
					e.preventDefault();
					fileName = e.target.files[0].name;
				});

				$('#edit').off().on("click", function(e){
						var file_data = $('#formFile').prop('files')[0];
							var form_data = new FormData();                  
							form_data.append('file', file_data);
							$.ajax({
								type: 'POST',
								url: 'function/upload-img-blog.php',
								contentType: false,
								processData: false,
								data: form_data,
								success:function(response) {
									$.ajax({
										url: "function/update-blog.php",
										type: "POST",
										cache: false,
										data:{
											id: $('#idblog').val(),
											oldfoto: $('#oldfoto').val(),
											judul: $('#judul').val(),
											content: $('#isi').val(),
											author: $('#author').val(),
											status: $('#status').val(),
											gambar: fileName,
										},
										success: function(dataResult){
											var dataResult = JSON.parse(dataResult);
											if(dataResult.statusCode==200){
												swal(
													"Well Done!",
													"You've been updated this product",
													"success"
												);
												$('#myModal').modal('hide');
												$('#example1').DataTable().ajax.reload(null, false);
											}
										}
									});
									$('#formFile').val('');
								}
							});
							return false;
						
				});
				
				$('#idblog').bind('change', function(e){
					e.preventDefault();
					var idblog = $(this).val();

					$.ajax({
						url: 'function/ajaxrespon-blog.php',
						type: 'GET',
						dataType: 'json',
						data: {
						'id_blog' : idblog
						},
						success: function (data) {
							$("#oldfoto").val(data['gambar']);
							$("#judul").val(data['judul']);
							$("#isi").val(data['isi']);
							$('#status').val(data['status']).attr('selected','selected');
							$("#author").val(data['author']);
							$("#foto").attr("src","blogs/" + data['gambar']);
						}
					});

					$('#delete').on('click', function(){
						$.ajax({
							url: "function/delete-blog.php",
							method: "POST",
							data: {
								ids: idblog,
								// gambar: gambar
							},
							success: function(data){
								// $('#hapus_'+id).fadeOut('slow');
								swal(
									"Well Done!",
									"You've been deleted this product",
									"success"
								);
								$('#myModal').modal('hide');
								$('#example1').DataTable().ajax.reload(null, false);
							}
						});
					});
				});
			});
		</script>
	</body>
</html>